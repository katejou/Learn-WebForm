﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MyFirstWebAPI.Controllers
{
    public class AryaCandidateController : ApiController
    {
        Models.AryaCandidate[] AryaCandidates = new Models.AryaCandidate[]
        {
            new Models.AryaCandidate{Name="peter", Id="a000000000", Age=30, Sex="Male",Email="peter@gmail.com"},
            new Models.AryaCandidate{Name="justin", Id="a11111111", Age=28, Sex="Male", Email="justin@gmail.com"},
            new Models.AryaCandidate{Name="terry", Id="a222222222", Age=32, Sex="Female", Email="terry@gmail.com"}
        };

        //取得所有應徵者的資料清單
        //IEnumerable：代表一個資料集，可以是List、Table...等，在Web API的應用中，我們通常以JSON格式回傳資料給前端。
        public IEnumerable<Models.AryaCandidate> GetAllAryaCandidates()
        {
            return AryaCandidates;
        }

        //取得特定名稱應徵者的資料
        //IHttpActionResult：代表一個HTTP的狀態，例如100、200、301、404、500...等。
        public IHttpActionResult GetAryaCandidates(string Name)
        {
            var myaCandidate = AryaCandidates.FirstOrDefault((c) => c.Name == Name);
            if (myaCandidate == null) return StatusCode(HttpStatusCode.NoContent);
            else return Ok(myaCandidate);
        }
    }
}
