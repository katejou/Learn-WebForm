﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace MyFirstWebAPI.Controllers
{
    public class AryaPostController : ApiController
    {
        [HttpPost]  //Postman--http://localhost:56219/api/AryaPost
        public IHttpActionResult Post([FromBody] string DATA)//舊寫法：public HttpResponseMessage Post([FromBody] string DATA)
                                                             //[FromBody]在postman測要加單引號，ex:'{"TYPE":"Q","PARAM1":"123456"}'
                                                             //(dynamic DATA)：測試資料有沒有單引號都可以，ex:'{"TYPE":"Q"}'or{"TYPE":"Q"}
                                                             //(JObject DATA)：不能有單引號，ex:{"TYPE":"Q"}
        {
            string controllerName = ControllerContext.RouteData.Values["controller"].ToString();
            string usr = HttpContext.Current.Request.Headers["usr"];
            string pwd = HttpContext.Current.Request.Headers["pwd"];
            var result = new
            {
                STATUS = false,
                MSG = ""
            };

            if (usr == "askey" && pwd == "key123")
            {
                JObject jo = JObject.Parse(DATA);//asp.net提取多層巢狀json資料的方法：https://codertw.com/%E5%89%8D%E7%AB%AF%E9%96%8B%E7%99%BC/208447/
                JArray jar = JArray.Parse(jo["members"].ToString());
                for (int i = 0; i < jar.Count; i++)
                {
                    JObject j = JObject.Parse(jar[i].ToString());
                    string name1 = j["NAME"].ToString();
                    string type1 = j["TYPE"].ToString();
                    string param1 = j["PARAM1"].ToString();
                    JArray jar2 = JArray.Parse(j["PARAM2"].ToString());
                    string inferno = jar2[0].ToString();
                    string turningtiny = jar2[1].ToString();
                    string teleportation = jar2[2].ToString();

                    //DataTable dt = new DataTable(); 
                    Int32 id = 0;

                    using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["Test_Conn"].ToString()))
                    {
                        cn.Open();
                        SqlCommand cmd = cn.CreateCommand();
                        SqlTransaction tx;

                        // 開始本地transaction.
                        tx = cn.BeginTransaction("SampleTransaction");

                        // 必須同時分配 transaction object 和 connection
                        // 到Command object以進行pending的本地transaction
                        cmd.Connection = cn;
                        cmd.Transaction = tx;

                        try
                        {
                            cmd.CommandText = $@"INSERT dbo.MemberS1 (NAME,TYPE,PARAM1) VALUES ('{name1}','{type1}','{param1}')";
                            cmd.ExecuteNonQuery();

                            cmd.CommandText = @"SELECT top 1 ID FROM dbo.MemberS1 ORDER BY ID DESC";
                            id = (Int32)cmd.ExecuteScalar();

                            cmd.CommandText = $@"INSERT dbo.PARAM2 (ID,Inferno,Turningtiny,Teleportation) VALUES ('{id}','{inferno}','{turningtiny}','{teleportation}')";
                            cmd.ExecuteNonQuery();

                            // 嘗試提交transaction.
                            tx.Commit();
                            Console.WriteLine("All records are written to database.");
                        }

                        catch (Exception ex1)
                        {
                            Console.WriteLine("Commit Exception Type: {0}", ex1.GetType());
                            Console.WriteLine("  Message: {0}", ex1.Message);
                            result = new
                            {
                                STATUS = true,
                                MSG = ex1.Message
                            };

                            // Attempt to roll back the transaction.
                            try
                            {
                                tx.Rollback();
                            }
                            catch (Exception ex2)
                            {
                                // 此catch塊將處理服務器上可能發生的任何會導致rollback失敗的錯誤，例如關閉的connection
                                Console.WriteLine("Rollback Exception Type: {0}", ex2.GetType());
                                Console.WriteLine("  Message: {0}", ex2.Message);
                            }
                        }//catch ex1 end
                        result = new
                        {
                            STATUS = true,
                            MSG = "成功"
                        };
                    }//sqlcmd end
                }//for end
            }//if end
            else
            {
                result = new
                {
                    STATUS = false,
                    MSG = "登入帳號或密碼有誤"
                };
            }
            return Ok(result);//IHttpActionResult，可參考：https://dotblogs.com.tw/grayyin/2016/04/19/144437
                              //舊寫法：return Request.CreateResponse(HttpStatusCode.OK, result);
        }


        private void Alert(string message)
        {
            throw new NotImplementedException();
        }
    }
}
